const crypto = require('crypto');
const { getServers, addServer, deleteServer, initDb } = require('./_lib/db');
const { getSession } = require('./_lib/auth');

function body(req) { return typeof req.body === 'object' && req.body ? req.body : {}; }
function clean(s, max = 120) { return String(s || '').trim().slice(0, max); }
function isAdmin(user) { return user && user.role === 'admin'; }

module.exports = async (req, res) => {
  try {
    await initDb();
    const user = await getSession(req);
    if (!user) return res.status(401).json({ ok: false, error: 'Unauthorized' });
    if (!isAdmin(user)) return res.status(403).json({ ok: false, error: 'Admin only' });

    if (req.method === 'GET') return res.json({ ok: true, servers: await getServers() });
    if (req.method === 'POST') {
      const b = body(req);
      const name = clean(b.name, 80);
      const host = clean(b.host, 255);
      const port = Number(b.port || 22);
      const username = clean(b.username || 'root', 80);
      const provider = clean(b.provider || 'custom', 80);
      if (!name || !host || !Number.isInteger(port) || port < 1 || port > 65535) return res.status(400).json({ ok: false, error: 'Name, host and valid port are required' });
      const server = { id: crypto.randomUUID(), name, host, port, username, provider, status: 'offline', created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
      await addServer(server);
      return res.status(201).json({ ok: true, server });
    }
    if (req.method === 'DELETE') {
      const id = clean(req.query?.id, 80);
      if (!id) return res.status(400).json({ ok: false, error: 'Missing server id' });
      await deleteServer(id);
      return res.json({ ok: true });
    }
    return res.status(405).json({ ok: false, error: 'Method not allowed' });
  } catch (e) { return res.status(500).json({ ok: false, error: e.message }); }
};
